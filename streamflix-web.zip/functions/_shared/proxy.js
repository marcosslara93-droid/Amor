// functions/_shared/proxy.js
//
// Capa de proxy/autenticación entre el frontend (Cloudflare Pages) y el
// backend FastAPI existente (streamflix-api). El navegador nunca ve
// BACKEND_URL ni BACKEND_API_KEY: solo llama a /api/* en el mismo dominio.
//
// Variables de entorno esperadas (configurar con `wrangler pages secret put`):
//   BACKEND_URL      -> ej. https://streamflix-api.tudominio.com
//   BACKEND_API_KEY  -> bearer token que ya usa tu backend FastAPI

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

/**
 * Reenvía una petición GET al backend FastAPI, agregando el bearer token
 * desde el entorno del Worker (nunca desde el cliente).
 *
 * @param {Object} env - env de Pages Functions (contiene los secrets)
 * @param {string} path - ruta en el backend, ej. "/movies" o "/live/123"
 * @param {URLSearchParams} [searchParams] - query params a reenviar tal cual
 */
export async function proxyToBackend(env, path, searchParams) {
  if (!env.BACKEND_URL) {
    return jsonResponse({ error: "BACKEND_URL no configurado" }, 500);
  }

  const url = new URL(path, env.BACKEND_URL);
  if (searchParams) {
    searchParams.forEach((value, key) => url.searchParams.set(key, value));
  }

  try {
    const backendRes = await fetch(url.toString(), {
      headers: {
        Authorization: `Bearer ${env.BACKEND_API_KEY ?? ""}`,
        Accept: "application/json",
      },
      // Cachea catálogo en el edge de Cloudflare por 2 minutos.
      // Los endpoints de stream (URLs firmadas HMAC con TTL) nunca deben cachearse.
      cf: path.startsWith("/stream") ? undefined : { cacheTtl: 120, cacheEverything: true },
    });

    const body = await backendRes.text();
    return new Response(body, {
      status: backendRes.status,
      headers: {
        "Content-Type": backendRes.headers.get("Content-Type") ?? "application/json",
        ...CORS_HEADERS,
      },
    });
  } catch (err) {
    return jsonResponse({ error: "No se pudo contactar streamflix-api", detail: String(err) }, 502);
  }
}

export function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS },
  });
}

export function handleOptions() {
  return new Response(null, { headers: CORS_HEADERS });
}
