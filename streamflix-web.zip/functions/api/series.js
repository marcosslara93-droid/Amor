// GET /api/series?category=populares  -> proxy hacia streamflix-api /series
import { proxyToBackend, handleOptions } from "../_shared/proxy.js";

export async function onRequestGet({ request, env }) {
  const { searchParams } = new URL(request.url);
  return proxyToBackend(env, "/series", searchParams);
}

export function onRequestOptions() {
  return handleOptions();
}
