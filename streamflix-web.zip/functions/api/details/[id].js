// GET /api/details/:id -> proxy hacia streamflix-api /details/:id
import { proxyToBackend, handleOptions } from "../../_shared/proxy.js";

export async function onRequestGet({ params, request, env }) {
  const { searchParams } = new URL(request.url);
  return proxyToBackend(env, `/details/${params.id}`, searchParams);
}

export function onRequestOptions() {
  return handleOptions();
}
