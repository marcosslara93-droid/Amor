// GET /api/live -> proxy hacia streamflix-api /live (canales de TV, multi-cuenta con fallback)
import { proxyToBackend, handleOptions } from "../_shared/proxy.js";

export async function onRequestGet({ request, env }) {
  const { searchParams } = new URL(request.url);
  return proxyToBackend(env, "/live", searchParams);
}

export function onRequestOptions() {
  return handleOptions();
}
