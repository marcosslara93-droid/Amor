// GET /api/movies?category=populares  -> proxy hacia streamflix-api /movies
import { proxyToBackend, handleOptions } from "../_shared/proxy.js";

export async function onRequestGet({ request, env }) {
  const { searchParams } = new URL(request.url);
  return proxyToBackend(env, "/movies", searchParams);
}

export function onRequestOptions() {
  return handleOptions();
}
