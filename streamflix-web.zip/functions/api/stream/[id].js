// GET /api/stream/:id -> proxy hacia streamflix-api /stream/:id
// Devuelve la URL firmada (HMAC + TTL) que ya genera tu backend.
// El host/usuario/contraseña reales del proveedor IPTV nunca pasan por aquí
// ni son visibles para el cliente ni para apps de interceptación de tráfico.
import { proxyToBackend, handleOptions } from "../../_shared/proxy.js";

export async function onRequestGet({ params, request, env }) {
  const { searchParams } = new URL(request.url);
  return proxyToBackend(env, `/stream/${params.id}`, searchParams);
}

export function onRequestOptions() {
  return handleOptions();
}
