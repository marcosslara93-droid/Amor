// public/js/app.js
import { CONFIG } from "./config.js";
import { api } from "./api.js";
import { renderRow, renderLiveGrid } from "./carousel.js";
import { playVod, playLive, initPlayerControls } from "./player.js";

const els = {
  header: document.querySelector(".header"),
  navLinks: document.querySelectorAll(".nav__link"),
  homeView: document.getElementById("view-home"),
  liveView: document.getElementById("view-live"),
  moviesRows: document.getElementById("movies-rows"),
  seriesRows: document.getElementById("series-rows"),
  liveGrid: document.getElementById("live-grid"),
  hero: document.getElementById("hero"),
  heroBackdrop: document.getElementById("hero-backdrop"),
  heroTitle: document.getElementById("hero-title"),
  heroMeta: document.getElementById("hero-meta"),
  heroDesc: document.getElementById("hero-desc"),
  heroPlay: document.getElementById("hero-play"),
  heroInfo: document.getElementById("hero-info"),
  modal: document.getElementById("detail-modal"),
  modalClose: document.getElementById("modal-close"),
  modalBody: document.getElementById("modal-body"),
  searchToggle: document.getElementById("search-toggle"),
  searchInput: document.getElementById("search-input"),
};

let heroItem = null;

function setActiveView(view) {
  els.homeView.classList.toggle("is-active", view === "home");
  els.liveView.classList.toggle("is-active", view === "live");
  els.navLinks.forEach((link) => link.classList.toggle("is-active", link.dataset.view === view));
}

async function loadHero() {
  const trending = await api.getMovies("tendencias");
  heroItem = trending[0];
  if (!heroItem) return;
  els.heroBackdrop.src = `${CONFIG.IMG_BASE}/original${heroItem.backdropPath ?? heroItem.posterPath}`;
  els.heroTitle.textContent = heroItem.title;
  els.heroMeta.textContent = [heroItem.year, heroItem.rating ? `★ ${heroItem.rating}` : null]
    .filter(Boolean)
    .join("  ·  ");
  els.heroDesc.textContent = heroItem.overview ?? "";
}

async function loadMovieRows() {
  for (const { key, label } of CONFIG.MOVIE_CATEGORIES) {
    try {
      const items = await api.getMovies(key);
      renderRow(els.moviesRows, label, items, openDetailModal);
    } catch (err) {
      console.error(`No se pudo cargar la categoría de películas "${key}"`, err);
    }
  }
}

async function loadSeriesRows() {
  for (const { key, label } of CONFIG.SERIES_CATEGORIES) {
    try {
      const items = await api.getSeries(key);
      renderRow(els.seriesRows, label, items, openDetailModal);
    } catch (err) {
      console.error(`No se pudo cargar la categoría de series "${key}"`, err);
    }
  }
}

async function loadLiveChannels() {
  try {
    const channels = await api.getLiveChannels();
    renderLiveGrid(els.liveGrid, channels, playLive);
  } catch (err) {
    console.error("No se pudo cargar la lista de canales", err);
  }
}

async function openDetailModal(item) {
  els.modal.classList.add("is-open");
  els.modalBody.innerHTML = `<p class="modal__loading">Cargando…</p>`;

  try {
    const details = await api.getDetails(item.id);
    els.modalBody.innerHTML = `
      <img class="modal__backdrop" src="${CONFIG.IMG_BASE}/w780${details.backdropPath ?? ""}" alt="" />
      <div class="modal__content">
        <h2 class="modal__title">${details.title}</h2>
        <p class="modal__meta">${[details.year, details.duration, details.genres?.join(", ")]
          .filter(Boolean)
          .join("  ·  ")}</p>
        <p class="modal__overview">${details.overview ?? ""}</p>
        <button class="btn btn--primary modal__play">▶ Reproducir</button>
      </div>
    `;
    els.modalBody.querySelector(".modal__play").addEventListener("click", () => playVod(details));
  } catch (err) {
    els.modalBody.innerHTML = `<p class="modal__loading">No se pudo cargar la información.</p>`;
    console.error(err);
  }
}

function closeDetailModal() {
  els.modal.classList.remove("is-open");
}

function initNav() {
  els.navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      setActiveView(link.dataset.view);
    });
  });
}

function initHeroButtons() {
  els.heroPlay.addEventListener("click", () => heroItem && playVod(heroItem));
  els.heroInfo.addEventListener("click", () => heroItem && openDetailModal(heroItem));
}

function initModal() {
  els.modalClose.addEventListener("click", closeDetailModal);
  els.modal.addEventListener("click", (e) => {
    if (e.target === els.modal) closeDetailModal();
  });
}

function initSearch() {
  els.searchToggle.addEventListener("click", () => {
    els.searchInput.classList.toggle("is-open");
    if (els.searchInput.classList.contains("is-open")) els.searchInput.focus();
  });
}

function initScrollHeader() {
  window.addEventListener("scroll", () => {
    els.header.classList.toggle("is-scrolled", window.scrollY > 40);
  });
}

async function init() {
  initNav();
  initHeroButtons();
  initModal();
  initSearch();
  initScrollHeader();
  initPlayerControls();

  await Promise.all([loadHero(), loadMovieRows(), loadSeriesRows(), loadLiveChannels()]);
}

document.addEventListener("DOMContentLoaded", init);
