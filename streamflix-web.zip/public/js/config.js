// public/js/config.js
export const CONFIG = {
  // Mismo origen: el navegador llama a /api/*, y Cloudflare Pages Functions
  // reenvía al backend FastAPI real. No hace falta CORS ni exponer el host.
  API_BASE: "/api",

  // Categorías mostradas en la fila de Inicio. Deben coincidir con los
  // valores que acepta ?category= en tu endpoint /movies y /series.
  MOVIE_CATEGORIES: [
    { key: "tendencias", label: "Tendencias ahora" },
    { key: "populares", label: "Populares en Películas" },
    { key: "accion", label: "Acción" },
    { key: "comedia", label: "Comedia" },
    { key: "terror", label: "Terror" },
  ],
  SERIES_CATEGORIES: [
    { key: "populares", label: "Series populares" },
    { key: "drama", label: "Drama" },
    { key: "animadas", label: "Animadas" },
  ],

  IMG_BASE: "https://image.tmdb.org/t/p", // ajusta si tu backend ya devuelve URLs completas
};
