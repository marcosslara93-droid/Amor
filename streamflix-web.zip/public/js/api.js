// public/js/api.js
import { CONFIG } from "./config.js";

async function getJSON(path) {
  const res = await fetch(`${CONFIG.API_BASE}${path}`);
  if (!res.ok) throw new Error(`API ${path} -> ${res.status}`);
  return res.json();
}

export const api = {
  getMovies: (category) => getJSON(`/movies?category=${encodeURIComponent(category)}`),
  getSeries: (category) => getJSON(`/series?category=${encodeURIComponent(category)}`),
  getLiveChannels: () => getJSON(`/live`),
  getDetails: (id) => getJSON(`/details/${id}`),
  getStreamUrl: (id) => getJSON(`/stream/${id}`),
};
