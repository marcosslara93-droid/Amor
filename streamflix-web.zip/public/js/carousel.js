// public/js/carousel.js
import { CONFIG } from "./config.js";

const posterObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const img = entry.target;
      img.src = img.dataset.src;
      img.removeAttribute("data-src");
      posterObserver.unobserve(img);
    });
  },
  { rootMargin: "200px" }
);

/**
 * @param {HTMLElement} rowsContainer - contenedor donde se insertan las filas
 * @param {string} title - título de la fila ("Acción", "Series populares"...)
 * @param {Array} items - [{ id, title, posterPath }]
 * @param {(item: object) => void} onSelect - callback al hacer click en una tarjeta
 */
export function renderRow(rowsContainer, title, items, onSelect) {
  if (!items || items.length === 0) return;

  const row = document.createElement("section");
  row.className = "row";
  row.innerHTML = `
    <h2 class="row__title">${title}</h2>
    <div class="row__track-wrap">
      <button class="row__arrow row__arrow--left" aria-label="Retroceder">‹</button>
      <div class="row__track"></div>
      <button class="row__arrow row__arrow--right" aria-label="Avanzar">›</button>
    </div>
  `;

  const track = row.querySelector(".row__track");

  items.forEach((item) => {
    const card = document.createElement("button");
    card.className = "card";
    card.setAttribute("aria-label", item.title);

    const img = document.createElement("img");
    img.className = "card__poster";
    img.alt = item.title;
    img.dataset.src = item.posterPath
      ? `${CONFIG.IMG_BASE}/w342${item.posterPath}`
      : "";
    img.loading = "lazy";
    posterObserver.observe(img);

    card.appendChild(img);
    card.innerHTML += `<span class="card__title">${item.title}</span>`;
    card.addEventListener("click", () => onSelect(item));
    track.appendChild(card);
  });

  row.querySelector(".row__arrow--left").addEventListener("click", () => {
    track.scrollBy({ left: -track.clientWidth * 0.9, behavior: "smooth" });
  });
  row.querySelector(".row__arrow--right").addEventListener("click", () => {
    track.scrollBy({ left: track.clientWidth * 0.9, behavior: "smooth" });
  });

  rowsContainer.appendChild(row);
}

/** Grid de canales en vivo (distinto de las filas de pósters de VOD) */
export function renderLiveGrid(container, channels, onSelect) {
  container.innerHTML = "";
  channels.forEach((ch) => {
    const tile = document.createElement("button");
    tile.className = "channel-tile";
    tile.setAttribute("aria-label", ch.name);
    tile.innerHTML = `
      <span class="channel-tile__live-dot" aria-hidden="true"></span>
      <img class="channel-tile__logo" src="${ch.logo ?? ""}" alt="" loading="lazy" />
      <span class="channel-tile__name">${ch.name}</span>
    `;
    tile.addEventListener("click", () => onSelect(ch));
    container.appendChild(tile);
  });
}
