// public/js/player.js
// Mantenemos playVod() y playLive() separados a propósito (no una función
// genérica), igual que LiveTvPlayerActivity está aislada del player de
// películas/series en la app de Android.
import { api } from "./api.js";

let hls = null;

function getPlayerEls() {
  return {
    overlay: document.getElementById("player-overlay"),
    video: document.getElementById("player-video"),
    closeBtn: document.getElementById("player-close"),
    label: document.getElementById("player-label"),
  };
}

function openPlayer(streamUrl, label) {
  const { overlay, video, label: labelEl } = getPlayerEls();
  labelEl.textContent = label ?? "";
  overlay.classList.add("is-open");

  if (window.Hls && window.Hls.isSupported()) {
    hls = new window.Hls();
    hls.loadSource(streamUrl);
    hls.attachMedia(video);
    hls.on(window.Hls.Events.MANIFEST_PARSED, () => video.play());
  } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
    video.src = streamUrl; // Safari: HLS nativo
    video.play();
  }
}

export function closePlayer() {
  const { overlay, video } = getPlayerEls();
  overlay.classList.remove("is-open");
  video.pause();
  video.removeAttribute("src");
  video.load();
  if (hls) {
    hls.destroy();
    hls = null;
  }
}

/** Reproduce una película o episodio de serie (VOD) */
export async function playVod(item) {
  const { url } = await api.getStreamUrl(item.id);
  openPlayer(url, item.title);
}

/** Reproduce un canal de TV en vivo */
export async function playLive(channel) {
  const { url } = await api.getStreamUrl(channel.id);
  openPlayer(url, channel.name);
}

export function initPlayerControls() {
  document.getElementById("player-close").addEventListener("click", closePlayer);
}
